/*----------------------------------------------------------------
Assignment No:
Write a program using TCP sockets for wired network to implement 
a. Peer to Peer Chat 

Roll NO:44
Batch:TEA-3
----------------------------------------------------------------
*/


					
import java.net.*;
import java.io.*;  


public class server
{
	public static void main(String args[])throws Exception
	{  
		ServerSocket ss=new ServerSocket(9000);  
		Socket s=ss.accept();  
		DataInputStream din=new DataInputStream(s.getInputStream());  
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
		  
		String str="",str2="";  
		while(!str.equals("stop")){  
			str=din.readUTF();  
			System.out.println("client says: "+str);  
			str2=br.readLine();  
			dout.writeUTF(str2);  
			dout.flush();  
		}  
		din.close();  
		s.close();  
		ss.close();  
	}
}



/*****************************
OUTPUT:

gescoe@gescoe-OptiPlex-3020:~/Desktop/gaurav/TCPIP$ javac server.java 
gescoe@gescoe-OptiPlex-3020:~/Desktop/gaurav/TCPIP$ java server 
hello client. 
client says: hello 
*********************************/




