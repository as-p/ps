/*---------------------------------------------------------------
Assignment No:
Write a program using TCP sockets for wired network to implement 
a. Peer to Peer Chat 

Roll NO:44 
Batch:TEA-3
---------------------------------------------------------------
*/
					
import java.net.*;
import java.io.*;  

public class Client {

	public static void main(String args[])throws Exception{  
		Socket s=new Socket("192.168.3.20",9000);  
		DataInputStream din=new DataInputStream(s.getInputStream());  
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
		  
		String str="",str2="";  
		while(!str.equals("stop")){  
			str=br.readLine();  
			dout.writeUTF(str);  
			dout.flush();  
			str2=din.readUTF();  
			System.out.println("Server says: "+str2);  
		}  
	  
		dout.close();  
		s.close();  
	}}

/*
OUTPUT:

gescoe@slave12:~/Desktop/gaurav $ javac Client.java
gescoe@slave12:~/Desktop/gaurav $ java Client
hello server.
Server says: hello  


*/
