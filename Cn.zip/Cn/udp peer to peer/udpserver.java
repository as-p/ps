/*----------------------------------------------------------------
Assignment No:
Write a program using UDP sockets for wired network to implement 
a. Peer to Peer Chat 
b. Multiuser Chat 
Demonstrate the packets captured traces using Wireshark Packet Analyzer Tool for peer to peer mode. 

Roll NO: 44
Batch:TEA-3
----------------------------------------------------------------
*/



import java.io.*;
import java.net.*;

public class udpserver
{
 public static void main(String args[]) throws IOException 
 {
    DatagramSocket ss = null; 
    //ServerSocket serversocket = null; Socket socket =null;
			
	ss = new DatagramSocket(9000); 
	//serversocket = new ServerSocket(8000);
		  
	byte[] receiveData = new byte[512];  
	//DataInputStream istream = new DataInputStream(socket.getInputStream());
	byte[] sendData  = new byte[512]; 
	//DataOutputStream ostream = new DataOutputStream(socket.getOutputStream());
		  
	System.out.println(" UDP Server socket is created and waiting for client");
		
	while(true) 
	 { 
  	   DatagramPacket receivePacket =new DatagramPacket(receiveData, receiveData.length); 
  
	   ss.receive(receivePacket); 
  
	   String message = new String(receivePacket.getData()); 
	   //myoperation = istream.readUTF();

	   System.out.println("Client Says: "+message);
		
	   InetAddress IPAddress = receivePacket.getAddress(); 
  
	   int port = receivePacket.getPort(); 
		  
	   message = "Thanks";
  
	   sendData = message.getBytes(); 
  
	   DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress,port); 
  
	   ss.send(sendPacket); //ostream.writeUTF(myoperation);
		  	 	
	   if(message.equals("Thanks")) break;
	  } 	
	 ss.close();
	 System.out.println("Server Stopped by User program");
  }
}


/*****************************
OUTPUT:
 gescoe@gescoe-OptiPlex-3020:~/Desktop$ javac udpserver.java 
gescoe@gescoe-OptiPlex-3020:~/Desktop$ java udpserver
 UDP Server socket is created and waiting for client
Client Says: Hello Server
Server Stopped by User program
gescoe@gescoe-OptiPlex-3020:~/Desktop$ 

********************************/
	 
  
		  
		
