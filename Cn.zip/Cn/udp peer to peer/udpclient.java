/*----------------------------------------------------------------
Assignment No:
Write a program using UDP sockets for wired network to implement 
a. Peer to Peer Chat 
b. Multiuser Chat 
Demonstrate the packets captured traces using Wireshark Packet Analyzer Tool for peer to peer mode. 

Roll NO:44 
Batch:TEA-3
----------------------------------------------------------------

*/

import java.io.*;
import java.net.*;

public class udpclient
{
  public static void main(String args[]) throws IOException
  {
	 String message = null;
	 DatagramSocket cs = null; 
			
	 cs = new DatagramSocket();  
 	  
	 byte[] receiveData = new byte[512];   

	 byte[] sendData  = new byte[512]; 
			  
	 System.out.println(" UDP Client socket is created and waiting for server");
		
     InetAddress IPAddress = InetAddress.getByName("localhost"); 
  
     int port = 9000;
		  
	 message = "Hello Server";
  
	 sendData = message.getBytes(); 
  
	 DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress,port); 
  
	 cs.send(sendPacket); 
	   
	 DatagramPacket receivePacket =new DatagramPacket(receiveData, receiveData.length); 
  
	 cs.receive(receivePacket); 
  
	 message = new String(receivePacket.getData());  
	
	 System.out.println("Server Says: "+message);
		
	}
}
/*
OUTPUT:
gescoe@slave12:~/Desktop$ javac udpclient.java 
gescoe@slave12:~/Desktop$ java udpclient
 UDP Client socket is created and waiting for server
Server Says: Thanks
gescoe@slave12:~/Desktop$ 
*/
