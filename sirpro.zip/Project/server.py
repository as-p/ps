from operator import itemgetter
from datetime import datetime
from flask import Flask,render_template,request,redirect,session,jsonify
from flask_pymongo import PyMongo
from flask_cors import CORS, cross_origin
from flask_mail import Mail, Message
from flask_uploads import UploadSet, configure_uploads
from random import randint
import hashlib,os
from openpyxl import *
import requests,time
import time
from bson.objectid import ObjectId
import math
import flask_pymongo
import pdfkit
import re
from datetime import datetime as dt
import time

app=Flask("__name__")
CORS(app)
app.config["MONGO_URI"] = "mongodb://localhost:27017/jit"

mongo=PyMongo(app)


mail=Mail(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'shindeashok.as.02@gmail.com'
app.config['MAIL_PASSWORD'] = 'sb@shinde'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)


def convert24HrTo12Hr(t):
	d = datetime.strptime(t, "%H:%M")
	return d.strftime("%I:%M %p")

def getNumbersOnly(s):
	n = ""
	for c in s:
		if c.isdigit():
			n+= c
	return n



@app.route("/sendnotice",methods=["POST"])
def sendnotice():
	mongo.db.notices.insert(request.get_json())
	return jsonify({"success":"true"})


@app.route("/getnotices",methods=["POST"])
def getnotices():
	notices = list(mongo.db.notices.find({},{"_id":False}))
	return jsonify({"success":"true","notices":notices})




@app.route("/fetchccclasses",methods=["POST"])
def fetchCCclasses():
	mobile =request.get_json()["mobile"]
	acadyear = request.get_json()["acadyear"]
	classes = mongo.db.class_description.find({"class_coordinator":mobile,"acad_year":acadyear},{"_id":False})
	#classes = mongo.db.class_description.find({"class_coordinator":mobile},{"_id":False})
	new_classes= []
	for cl in classes:
		new_classes.append(cl)
	return jsonify({"success":"true","classes":new_classes})

@app.route("/makedefaulterlist",methods=["POST"])
def makeDefaulterList():
	class_uid = request.get_json()["class_uid"]
	startdate = request.get_json()["startdate"]
	enddate = request.get_json()["enddate"]
	startdate = dt.strptime(startdate, "%d-%m-%Y")
	enddate = dt.strptime(enddate, "%d-%m-%Y")
	acadyear = request.get_json()["acadyear"]

	
	
	work_matrix = []
	tmp =["Roll No","Student Name","Percentage","Theory","Practical"]
	abbreviations = []
	unique_subjects = []

	subject_types = []
	# sub_types = ["Theory","Practical","Tutorial"]
	# for t in sub_types:
	# 	print t

	all_subjects= mongo.db.subjects.find({"cuid":class_uid},{"_id":False,"subject_uid":True,"abbr":True,"faculty_name":True,"subjecttype":True})
	all_subjects =  list(all_subjects)
	print all_subjects	

	all_subjects = sorted(all_subjects,key=itemgetter('subjecttype'),reverse=True)

	for subject in all_subjects:
		if  subject["subject_uid"]+"<br/>"+subject["faculty_name"] not in tmp:
			tmp.append(subject["subject_uid"]+"<br/>"+subject["faculty_name"])

		if subject["subject_uid"] not in unique_subjects:
			#print subject["subject_uid"]
			unique_subjects.append(subject["subject_uid"])
			abbreviations.append(subject["abbr"]+"<br/>"+subject["faculty_name"]+"<br/>"+subject["subjecttype"])
			subject_types.append(subject["subjecttype"].lower())
	work_matrix.append(tmp)
	#print unique_subjects
	#print work_matrix

	studentsList = mongo.db.students.find({"class":class_uid},{"_id":False,"name":True,"rollno":True})
	studentList = []
	total_percentage = []
	for student in studentsList:
		student["rollno"] = int(student["rollno"])
		studentList.append(student)

	studentList = sorted(studentList,key=itemgetter('rollno'))

	blank_att = []
	for us in unique_subjects[2:]:
		blank_att.append(0)
	for student in studentList:
		work_matrix.append([student["rollno"],student["name"],0,0,0,0,0,0,0])
	# print "Work Matrix"
	# print work_matrix


	subjectcntr = 0

	header = ["Roll No","Student Name","Total %","Practical %","Theory %"]


	for subject_uid,abbreviation,abbr,subject_type in zip(unique_subjects,tmp[3:],abbreviations,subject_types):	
		print abbr
		subjectAttendance = mongo.db.attendance.find({"subject_uid":subject_uid},{"_id":False,"faculty":False})
		subjectAttendance = list(subjectAttendance)

		tempAttendance = []
		for att in subjectAttendance:
			try:
				#print att["sessiondate"]
				datetocomp = dt.strptime(att["sessiondate"], "%d-%m-%Y")
			except:
				#print att["sessiondate"]
				datetocomp = dt.strptime(att["sessiondate"], "%d/%m/%Y")

			att["datetocomp"] = datetocomp
			epoch_time = (datetocomp - datetime(1970, 1, 1)).total_seconds()
			att["epoch"] = epoch_time
			
			if datetocomp >= startdate and datetocomp <= enddate:				
				tempAttendance.append(att)


		tempAttendance = sorted(tempAttendance, key=itemgetter('epoch'))
		#print tempAttendance
		
		subjectAttendance = tempAttendance

		studentsList = mongo.db.students.find({"class":class_uid},{"_id":False,"name":True,"rollno":True})
		studentList = []
		for student in studentsList:
			student["rollno"] = int(student["rollno"])
			studentList.append(student)
		studentList = sorted(studentList,key=itemgetter('rollno'))
		subjectAttendanceList = []
		subjectAttendance = list(subjectAttendance)

		

		if len(subjectAttendance)>0:
			header.append(abbr)
			if "batch" in subjectAttendance[0]:		


				batches = []
				batch_presenty=[]
				for sub in subjectAttendance:
					if sub["batch"] not in batches:
						batches.append(sub["batch"])
				
				for b in batches:
					tmp=[]
					for sub in subjectAttendance:
						if b==sub["batch"]:
							tmp.append(sub)
					batch_presenty.append(tmp)	
				

				total_work_matrix = []
				
				wb = Workbook()
				
				for b,current_batch in zip(batches,batch_presenty):

					studentsList = mongo.db.students.find({"class":class_uid,"batch":b},{"_id":False,"name":True,"rollno":True})
					rollnos = []

					for r in studentsList:
						r["rollno"] = int(r["rollno"])
						rollnos.append(r)

					rollnos = sorted(rollnos,key=itemgetter('rollno'))
					
					wholedocmatrix =[]
					tmp =["roll no","student name"]
					tmp2=["",""]
					for r in current_batch:
						tmp.append(r["sessiondate"])
						tmp2.append(convert24HrTo12Hr(r["sessiontime"]))
					wholedocmatrix.append(tmp)
					wholedocmatrix.append(tmp2)

					for r in rollnos:
						wholedocmatrix.append([r["rollno"],r["name"]])
			
					
					
					for r in current_batch:					
						cnt =2				
						for p in rollnos:
							
							flag = 0
							for rec in r["presenty"]:
								if str(rec["rollno"]) == str(p["rollno"]):
									wholedocmatrix[cnt].append(int(rec["present"]))
									cnt+=1
									flag=1
							if flag ==0:
								wholedocmatrix[cnt].append(0)
								cnt+=1
							

					for row in wholedocmatrix[2:]:
						total = 0

						for v in row[2:]:
							total+=int(v)

						
						percatt =float(total)/len(row[2:])
						percatt *= 100
						percatt = round(percatt,2)
						row.append(str(percatt)+"%")
					
					
					total_work_matrix += wholedocmatrix[2:]				
					
			
				totalattendance = []
				for t in total_work_matrix:
					#print t
					tot =0 
					for r in t[2:-1]:
						tot+=int(r)

					totalattendance.append({"rollno":t[0],"attended":tot,"total_sessions":len(t[2:-1]),"subjecttype":subject_type})
				sorted(totalattendance,key=itemgetter('rollno'))
				rollnos_marked = []
				for w in work_matrix[1:]:
					rollnos_marked.append(w[0])
				for t in totalattendance:
					#print "t",t
					for w in work_matrix:
						#print "w",w
						if str(w[0])== str(t["rollno"]):
							rollnos_marked.remove(w[0])
							w.append(str(t["attended"]) +"/"+str(t["total_sessions"]) )
							#w[2]+= round((t["attended"]*100)/t["total_sessions"],2) 
							if t["subjecttype"]=="practical" or t["subjecttype"] =="tutorial": 
								w[3]+= t["attended"]
								w[4]+=t["total_sessions"]
								w[5]=round((w[3]*100)/w[4],2)
							else:
								w[6]+= t["attended"]
								w[7]+=t["total_sessions"]
								w[8]=round((w[6]*100)/w[7],2)
				#print rollnos_marked
				for remaining in rollnos_marked:
					for w in work_matrix:
						if str(w[0])== str(remaining):
							w.append("NA")



			else:
			
				wholedocmatrix =[]
				tmp =["roll no","student name"]
				tmp2=["",""]
				for r in subjectAttendance:
					tmp.append(r["sessiondate"])
					tmp2.append(convert24HrTo12Hr(r["sessiontime"]))
				wholedocmatrix.append(tmp)
				wholedocmatrix.append(tmp2)
				
				for r in studentList:
					wholedocmatrix.append([r["rollno"],r["name"]])
				
				attendance_matrix = []
				rollnos = []
				for student in studentList:
					rollnos.append(student["name"])
			
				for r in subjectAttendance:
					cnt =2 
					for p in studentList:
						if rollnos.index(p["name"]) >= 0:
							flag =0
							for record in r["presenty"]:
								if record["student_name"] == p["name"]:
									wholedocmatrix[cnt].append(int(record["present"]))
									flag =1
							if flag == 0:
								wholedocmatrix[cnt].append(0)
						else:
							wholedocmatrix[cnt].append(0)
						cnt+=1

							
			
				for row in wholedocmatrix[2:]:
					total = 0
					for v in row[2:]:
						total+=int(v)
					percatt =float(total)/len(row[2:])
					percatt *= 100
					percatt = round(percatt,2)
					row.append(str(percatt)+"%")
					
				total_sessions =[]
				for row in wholedocmatrix[2:]:
					tot =0 
					for r in row[2:-1]:
						tot+=int(r)
					#print row[0],tot
					total_sessions.append({"rollno":row[0],"attended":tot,"total_sessions":len(row[2:-1]),"subjecttype":subject_type})					
				sorted(total_sessions,key=itemgetter('rollno'))
				downloadlink= "/opt/lampp/htdocs/excelreports/"+subject_uid.replace("/","")+str(randint(100000,99999999))+".xlsx"
				#wb.save(filename= downloadlink )
				for subjAtt in subjectAttendance:
					subjectAttendanceList.append(subjAtt["presenty"])
				downloadlink1= downloadlink.split("htdocs/")[1]
				# print "----"		
				# print subject_uid
				
				for t in total_sessions:
					#print t
					for w in work_matrix:
						if str(w[0])== str(t["rollno"]):
							w.append(str(t["attended"]) +"/"+str(t["total_sessions"]) )
							#w[2]+= round((t["attended"]*100)/t["total_sessions"],2) 
							if t["subjecttype"]=="practical" or t["subjecttype"] =="tutorial":
								w[3]+= t["attended"]
								w[4]+=t["total_sessions"]
								w[5]=round((w[3]*100)/w[4],2)
							else:
								w[6]+= t["attended"]
								w[7]+=t["total_sessions"]
								w[8]=round((w[6]*100)/w[7],2)

		else:
			print "NO attendance found"
			pass
			
		subjectcntr +=1
	# wb = Workbook()
	# ws = wb.active
	# ws.append(work_matrix[0])
	class_details = mongo.db.class_description.find({"class_unique_id":class_uid,"acad_year":acadyear})
	#class_details = mongo.db.class_description.find({"class_unique_id":class_uid})
	class_details = list(class_details)[0]
	pdfstring = "<html><head><meta name='pdfkit-page-size' content='Legal'/><meta name='pdfkit-orientation' content='Landscape'/></head><body>"
	pdfstring+="<h4> "
	pdfstring+= class_details["class"] +"  "
	pdfstring+= class_details["branch"] +"  "
	pdfstring+= class_details["division"] +"  "
	pdfstring+= "Semester: "
	pdfstring+= class_details["semester"] +"  "
	pdfstring+= "</h4>"
	pdfstring += "<table > "

	headerstring = "<tr>"
	for head in header:
		headerstring+="<td>"
		headerstring+=str(head)
		headerstring+="</td>"
	headerstring+="</tr>"

	pdfstring+=headerstring

	for w in work_matrix[1:]:
		#w.append(round(sum(w[3:])/len(w[3:]),2))
		
		w[2] = str(round((w[5] + w[8])/2,2) )+"%"
		w[5] = str(w[5])+"%"
		w[8] = str(w[8]) +"%"
		pdfstring += "<tr>"
		for word in w[0:3]+ [w[5]]  +w[8:]:
			pdfstring+="<td>"
			pdfstring += str(word)
			pdfstring+="</td>"

		pdfstring+="</tr>"
	pdfstring +="</body></html>"
		#ws.append(w)
	downloadlink= "/opt/lampp/htdocs/excelreports/"+str(time.time())+".pdf"
	#wb.save(filename= downloadlink )
	css =['pdfstyle.css']
	pdfkit.from_string(pdfstring,downloadlink,css=css)

	downloadlink1= downloadlink.split("htdocs/")[1]
	return jsonify({"success":"true","downloadlink":downloadlink1}) 

	

@app.route("/downloadexcelreport",methods=["POST"])
def downloadExcelReport():
	subject_uid = request.get_json()["subject_uid"]
	class_uid = request.get_json()["class_uid"]

	subjectAttendance = mongo.db.attendance.find({"subject_uid":subject_uid},
		{"_id":False,"faculty":False})

	studentsList = mongo.db.students.find({"class":class_uid},{"_id":False,"name":True,"rollno":True})
	studentList = []
	for student in studentsList:
		student["rollno"] = int(student["rollno"])
		studentList.append(student)
	studentList = sorted(studentList,key=itemgetter('rollno'))
	#print studentList
	subjectAttendanceList = []
	subjectAttendance = list(subjectAttendance)



	if len(subjectAttendance)>0:
		if "batch" in subjectAttendance[0]:		


			batches = []
			batch_presenty=[]
			for sub in subjectAttendance:
				if sub["batch"] not in batches:
					batches.append(sub["batch"])
			
			for b in batches:
				tmp=[]
				for sub in subjectAttendance:
					if b==sub["batch"]:
						tmp.append(sub)
				batch_presenty.append(tmp)	

			


			wb = Workbook()
			cntr=0
			for b,current_batch in zip(batches,batch_presenty):

				studentsList = mongo.db.students.find({"class":class_uid,"batch":b},{"_id":False,"name":True,"rollno":True})
				rollnos = []
				# studentList = []
				# for student in studentsList:
				# 	student["rollno"] = int(student["rollno"])
				# 	studentList.append(student)
				# studentList = sorted(studentList,key=itemgetter('rollno'))
				# studentsList = studentList

				for r in studentsList:
					r["rollno"] = int(r["rollno"])
					rollnos.append(r)

				rollnos = sorted(rollnos,key=itemgetter('rollno'))
				if cntr>=1:
					ws = wb.create_sheet("Batch"+b)
				else:
					ws = wb.active
					ws.title="Batch"+b
				wholedocmatrix =[]
				tmp =["roll no","student name"]
				tmp2=["",""]
				for r in current_batch:
					tmp.append(r["sessiondate"])
					tmp2.append(convert24HrTo12Hr(r["sessiontime"]))
				wholedocmatrix.append(tmp)
				wholedocmatrix.append(tmp2)

				for r in rollnos:
					wholedocmatrix.append([r["rollno"],r["name"]])
		
				
				
				for r in current_batch:					
					cnt =2				
					for p in rollnos:
						
						flag = 0
						for rec in r["presenty"]:
							if str(rec["rollno"]) == str(p["rollno"]):
								wholedocmatrix[cnt].append(rec["present"])
								cnt+=1
								flag=1
						if flag ==0:
							wholedocmatrix[cnt].append('0')
							cnt+=1


						

				for row in wholedocmatrix[2:]:
					total = 0
					for v in row[2:]:
						total+=int(v)
					
					percatt =float(total)/len(row[2:])
					percatt *= 100
					percatt = round(percatt,2)
					row.append(str(percatt)+"%")
				
				
				for row in wholedocmatrix:
					ws.append(row)
				cntr+=1
			downloadlink= "/opt/lampp/htdocs/excelreports/"+subject_uid.replace("/","")+str(time.time())+".xlsx"
			sheet_names = wb.get_sheet_names()

			wb.save(filename= downloadlink )

			downloadlink1= downloadlink.split("htdocs/")[1]

			return jsonify({"success":"true","downloadlink":downloadlink1})


		else:
			wb = Workbook()
			ws = wb.active
			wholedocmatrix =[]
			tmp =["roll no","student name"]
			tmp2=["",""]
			for r in subjectAttendance:
				tmp.append(r["sessiondate"])
				tmp2.append(convert24HrTo12Hr(r["sessiontime"]))
			wholedocmatrix.append(tmp)
			wholedocmatrix.append(tmp2)
			
			for r in studentList:
				wholedocmatrix.append([r["rollno"],r["name"]])
			
			attendance_matrix = []
			rollnos = []
			for student in studentList:
				rollnos.append(student["name"])
		
			for r in subjectAttendance:
				cnt =2 
				for p in studentList:
					if rollnos.index(p["name"]) >= 0:
						flag =0
						for record in r["presenty"]:
							if record["student_name"] == p["name"]:
								wholedocmatrix[cnt].append(record["present"])
								flag =1
						if flag == 0:
							wholedocmatrix[cnt].append('0')
					else:
						wholedocmatrix[cnt].append('0')
					cnt+=1

						
		
			for row in wholedocmatrix[2:]:
				total = 0
				for v in row[2:]:
					total+=int(v)
				percatt =float(total)/len(row[2:])
				percatt *= 100
				percatt = round(percatt,2)
				row.append(str(percatt)+"%")
				
			for row in wholedocmatrix:
				ws.append(row)
				
			downloadlink= "/opt/lampp/htdocs/excelreports/"+subject_uid.replace("/","")+str(randint(100000,99999999))+".xlsx"
			wb.save(filename= downloadlink )
			for subjAtt in subjectAttendance:
				subjectAttendanceList.append(subjAtt["presenty"])
			downloadlink1= downloadlink.split("htdocs/")[1]		
			

			return jsonify({"success":"true","downloadlink":downloadlink1})
	else:
		return jsonify({"success":"false","reason":"No attendance found!"})

@app.route("/getstaffsubjectwiseattendance", methods=["POST"])
def getStaffSubjectwiseAttendance():	
	subject_uid = request.get_json()["subject_uid"]
	print subject_uid
	subjectAttendance = mongo.db.attendance.find({"subject_uid":subject_uid},
		{"faculty":False})
	
	subjectAttendanceList = []
	for subjAtt in subjectAttendance:
		if "topic" not in subjAtt:
			subjAtt["topic"] ="-"
		subjAtt["_id"] = str(subjAtt["_id"])
		try:
			datetocomp = dt.strptime(subjAtt["sessiondate"], "%d-%m-%Y")
		except:
			datetocomp = dt.strptime(subjAtt["sessiondate"], "%d/%m/%Y")
		#subjAtt["datetocomp"] = datetocomp
		epoch_time = (datetocomp - datetime(1970, 1, 1)).total_seconds()
		subjAtt["epoch"] = epoch_time
		subjectAttendanceList.append(subjAtt)	
	subjectAttendanceList = sorted(subjectAttendanceList, key=itemgetter('epoch'),reverse=True)
	#print subjectAttendanceList
	return jsonify({"success":"true","message":"Successfully Fetched","subject_wise_attendance":subjectAttendanceList,"total_sessions":len(subjectAttendanceList)})


@app.route("/getattendancestudents", methods=["POST"])
def getattendanceStudents():
	print request.get_json()	
	if "email" in request.get_json():
		student_class = mongo.db.students.find({"email":request.get_json()["email"]},{"class":True,"_id":True,"batch":True,"mobile":True,"name":True})	
	elif "mobile" in request.get_json():
		email = mongo.db.students.find_one({"mobile":request.get_json()["mobile"]},{"email":True})
		email = email["email"]
		student_class = mongo.db.students.find({"email":email},{"class":True,"_id":True,"batch":True,"mobile":True,"name":True})
	student_class = list(student_class)
	if len(student_class) ==0:
		return jsonify({"success":"false","message":"No Class found"})
	print "class---",student_class
	l = len(student_class)
	print student_class
	student_class = student_class[l-1]
	#print student_class

	attendance_records = mongo.db.attendance.find({"class_uid":student_class["class"],"subjecttype":"Theory"},{"_id":False})
	try:
		attendance_records2 = mongo.db.attendance.find({"class_uid":student_class["class"],"subjecttype":"Practical","batch":student_class["batch"]},{"_id":False})
	except:
		attendance_records2 = []

	try:
		attendance_records3 = mongo.db.attendance.find({"class_uid":student_class["class"],"subjecttype":"Tutorial","batch":student_class["batch"]},{"_id":False})
	except:
		attendance_records3 =[]

	attendance_records = list( attendance_records )
	attendance_records2 = list( attendance_records2 )
	attendance_records3 = list( attendance_records3 )
	subjects = mongo.db.subjects.find({"cuid":student_class["class"]},{"_id":False,"subjectname":True})
	subjectnames = []
	for sub in subjects:
		subjectnames.append(sub["subjectname"])
	subject_wise_attendance = {}	
	for atten in attendance_records:
		
		ind_presenty =[]
		for a in atten["presenty"]:			
			if a["student_id"] == student_class["mobile"]:
				ind_presenty.append(a)
		atten["presenty"]= list(ind_presenty)
	
		if atten["subjectname"] not in subject_wise_attendance:
			subject_wise_attendance[atten["subjectname"]] = [atten]
		else:
			subject_wise_attendance[atten["subjectname"]].append(atten)

	for atten in attendance_records2:
		
		ind_presenty =[]
		for a in atten["presenty"]:			
			if a["student_id"] == student_class["mobile"]:
				ind_presenty.append(a)
		atten["presenty"]= list(ind_presenty)
	
		if atten["subjectname"] not in subject_wise_attendance:
			subject_wise_attendance[atten["subjectname"]] = [atten]
		else:
			subject_wise_attendance[atten["subjectname"]].append(atten)

	for atten in attendance_records3:
		
		ind_presenty =[]
		for a in atten["presenty"]:			
			if a["student_id"] == request.get_json()["mobile"]:
				ind_presenty.append(a)
		atten["presenty"]= list(ind_presenty)
	
		if atten["subjectname"] not in subject_wise_attendance:
			subject_wise_attendance[atten["subjectname"]] = [atten]
		else:
			subject_wise_attendance[atten["subjectname"]].append(atten)

	#print subject_wise_attendance
	for sub_key,sub_val in subject_wise_attendance.iteritems():
		#print sub_key,sub_val
		for rec in sub_val:
			try:
				rec["waspresent"] = rec["presenty"][0]["present"]
				del rec["presenty"]
			except:
				rec["waspresent"] = 0

	sub_attendance = []

	for k,v in subject_wise_attendance.iteritems():
		#print v

		for dayatt in v:
			dayatt["sessiondate"]
			datetocomp = dt.strptime(dayatt["sessiondate"], "%d-%m-%Y")
			dayatt["datetocomp"] = datetocomp
			epoch_time = (datetocomp - datetime(1970, 1, 1)).total_seconds()
			dayatt["epoch"] = epoch_time

		v = sorted(v, key=itemgetter('epoch'),reverse = True)


		tmp = {}
		tmp["subject"]= k 
		n_session_present = 0
		for n in v:
			if n["waspresent"]=="1":
				n_session_present+=1
		tmp["total_sessions"] = str(len(v))
		tmp["details"] =v
		tmp["session_attended"]=str(n_session_present)
		sub_attendance.append(tmp)
	return jsonify({"success":"true","message":"Successfully Fetched","subject_wise_attendance":sub_attendance,"studentname":student_class["name"]})
	
@app.route("/updateattendance", methods=["POST"])
def updateattendance():
	recs = {}
	for key,value in request.get_json().iteritems():
		recs[key] = value
	
	rec_id = request.get_json()["id"]
	
	already_filled= mongo.db.attendance.find_one({"class_uid":recs["class_uid"],"sessiontime":recs["sessiontime"],"sessiondate":recs["sessiondate"]})
	if recs["subjecttype"]=="Practical":
		already_filled= mongo.db.attendance.find_one({"class_uid":recs["class_uid"],"sessiontime":recs["sessiontime"],"sessiondate":recs["sessiondate"],"batch":recs["batch"]})

	
	checked_students = []
	for stud in request.get_json()["students"]:
		checked_students.append(str(stud["student_name"]))
	if "batch" in request.get_json():
		fetched_students = mongo.db.students.find({"class":request.get_json()["class_uid"],"batch":request.get_json()["batch"]},{"_id":False})
	else:
		fetched_students = mongo.db.students.find({"class":request.get_json()["class_uid"]},{"_id":False})

	present_students =[]
	total_present = 0
	total_absent = 0
	if request.get_json()["presentabsent"] == 'present':		
		for stud in fetched_students:
			
			if str(stud["name"]) in checked_students:					
				present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"1"})
				total_present+=1
			else:
				
				present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"0"})
				total_absent+=1
	elif request.get_json()["presentabsent"] == 'absent':
		
		for stud in fetched_students:
			if str(stud["name"]) in checked_students:
				present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"0"})
				total_absent+=1
			else:
				present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"1"})
				total_present+=1
 
	del recs["students"]
	recs["present"]=str(total_present)
	recs["absent"]=str(total_absent)
	recs["presenty"]= present_students
	

	mongo.db.attendance.remove({"_id":ObjectId(rec_id)})
	mongo.db.attendance.insert(recs)
	return jsonify({"success":"true","message":"Successfully Updated"})


	
@app.route("/addattendance", methods=["POST"])
def addattendance():
	recs = {}
	for key,value in request.get_json().iteritems():
		recs[key] = value
	
	toupdate = None
	try:
		toupdate = recs["update"]
	except:
		pass
	
	already_filled= mongo.db.attendance.find_one({"class_uid":recs["class_uid"],"sessiontime":recs["sessiontime"],"sessiondate":recs["sessiondate"]},{"presenty":False,"_id":False})
	if recs["subjecttype"]=="Practical" or recs["subjecttype"]=="Tutorial":
		already_filled= mongo.db.attendance.find_one({"class_uid":recs["class_uid"],"sessiontime":recs["sessiontime"],"sessiondate":recs["sessiondate"],"batch":recs["batch"]},{"presenty":False,"_id":False})
	#print already_filled
	if already_filled != None and toupdate == None:
		return jsonify({"success":"false","message":"Duplicate Entry!","conducted_by":already_filled})
	else:
		if toupdate == "true":
			mongo.db.attendance.remove({"_id":ObjectId(already_filled["_id"])})		
		sms_receivers = []
		checked_students = []
		for stud in request.get_json()["students"]:
			checked_students.append(str(stud["parent_mobile"]))
		if "batch" in request.get_json():
			fetched_students = mongo.db.students.find({"class":request.get_json()["class_uid"],"batch":request.get_json()["batch"]},{"_id":False})
		else:
			fetched_students = mongo.db.students.find({"class":request.get_json()["class_uid"]},{"_id":False})

		present_students =[]
		total_present = 0
		total_absent = 0
		print request.get_json()["presentabsent"]
		print fetched_students
		print checked_students
		if request.get_json()["presentabsent"] == 'present':		
			for stud in fetched_students:
				if str(stud["parent_mobile"]) in checked_students:					
					present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"1"})
					total_present+=1
				else:
					sms_receivers.append(stud["parent_mobile"])  
					present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"0"})
					total_absent+=1
		elif request.get_json()["presentabsent"] == 'absent':
			sms_receivers = checked_students
			for stud in fetched_students:
				if str(stud["parent_mobile"]) in checked_students:
					present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"0"})
					total_absent+=1
				else:
					present_students.append({"student_id":stud["mobile"],"student_name":stud["name"],"rollno":stud["rollno"],"present":"1"})
					total_present+=1
	 
		del recs["students"]
		recs["present"]=str(total_present)
		recs["absent"]=str(total_absent)
		recs["presenty"]= present_students
		

		numbers=sms_receivers
		snumbs = []
		dupn =[]
		for n in numbers:
			snumbs.append(str(n))
			dupn.append(str(n))
		numbers= snumbs
		
		for number in numbers:			
			sent = mongo.db.smscounter.find_one({"parent_mobile":number,"sessiondate":request.get_json()["sessiondate"]})	
			if sent!=None:
				dupn.remove(number)
		numbers = dupn
		message = ""
		if len(numbers)>0 and request.get_json()["sendsms"]=="true":
			time_24hr = time.strptime(request.get_json()["sessiontime"], "%H:%M")
			timevalue_12hour = time.strftime( "%I:%M %p", time_24hr)

			message='Your ward was absent for lecture '+request.get_json()["subjectname"]+" at "+timevalue_12hour +" on "+request.get_json()["sessiondate"]
			
			smsurl = "http://www.smsjust.com/blank/sms/user/urlsms.php?username=Gokhalenew&pass=123456&senderid=GESCOE&dest_mobileno="
			for num in numbers:
				smsurl+=str(num)+","
			smsurl=smsurl[:-1]
			smsurl+="&message="
			message = message.replace("&","n")
			smsurl+=message
			smsurl+="&response=Y"
			try:
				sresponse = requests.get(smsurl,timeout=5)
			except:
				return jsonify({"success":"false","message":"SMS API Failed. Please try again"})
			
			for number in numbers:
				mongo.db.smscounter.insert({"parent_mobile":number,"sessiondate":request.get_json()["sessiondate"],"message":message})            
		mongo.db.attendance.insert(recs)
		return jsonify({"success":"true","message":"Successfully Added"})

@app.route("/uploadimagenotice", methods=["POST"])
def uploadimagenotice():
	filename =""
	target="/opt/lampp/htdocs/uploads"
	noticecontent =  request.form['noticecontent']
	for upload in request.files.getlist("file"):
		filename = str(time.time())+"__"+upload.filename
		destination = "/".join([target, filename])
		
		upload.save(destination)
	print noticecontent
	return jsonify({"success":"true","image_url":destination})



@app.route("/uploadstudents", methods=["POST"])
def uploadstudents():
	filename =""
	target="/opt/lampp/htdocs/uploads"
	class_selected =  request.form['class']
	for upload in request.files.getlist("file"):
		filename = upload.filename
		destination = "/".join([target, filename])
		
		upload.save(destination)
		wb = load_workbook(filename = destination)
		sheet_name =wb.get_sheet_names()[0]
		sheet = wb.get_sheet_by_name(sheet_name)
		max_rows= sheet.max_row
		max_cols = sheet.max_column
		studentinfo_keys =["rollno","name","email","mobile","parent_mobile"]
		for r in range(2,max_rows+1):
			cntr=0
			tmp= {}
			for c in range(1,6):
				tmp[studentinfo_keys[cntr]] =sheet.cell(row=r,column=c).value
				cntr+=1
			for k in tmp:
				if tmp[k] == None or tmp[k] == '':
					return jsonify({"success":"false","message":"No Blank Fields are allowed"})

			if tmp['rollno'] != None:
				if tmp["mobile"] != None:
					tmp["class"] = class_selected
					tmp["rollno"]= str(tmp["rollno"])
					
					tmp["mobile"]= getNumbersOnly(str(tmp["mobile"]))[:10] 
					tmp['email'] = str(tmp['email'])
					dupl = mongo.db.students.find_one({"mobile":tmp["mobile"]})
					#print dupl
					mongo.db.students.insert(tmp)
		os.remove(destination)
	return jsonify({"success":"true","message":"Successfully Uploaded"})


@app.route("/uploadstaff", methods=["POST"])
def uploadstaff():
	filename =""
	target="/opt/lampp/htdocs/uploads"
	branch_selected =  request.form['branch']
	for upload in request.files.getlist("file"):
		filename = upload.filename
		destination = "/".join([target, filename])		
		upload.save(destination)
		wb = load_workbook(filename = destination)
		sheet_name =wb.get_sheet_names()[0]
		sheet = wb.get_sheet_by_name(sheet_name)
		max_rows= sheet.max_row
		max_cols = sheet.max_column
		staffinfo_keys =["staff_name","email","mobile_no","qualification","branch"]
		for r in range(2,max_rows+1):
			cntr=0
			tmp= {}
			for c in range(1,6):
				tmp[staffinfo_keys[cntr]] =sheet.cell(row=r,column=c).value
				cntr+=1
			#if tmp['staff_name'] != 'None':
			if tmp['staff_name'] != None:
				tmp["staff_name"] = str(tmp["staff_name"])
				tmp["branch"] = branch_selected
				tmp["email"]= str(tmp["email"]).lower().strip()
				tmp["mobile_no"]=str(tmp["mobile_no"])[:10]
				tmp["staff_unique_id"]=str(tmp["mobile_no"])[:10]
				tmp["qualification"]=str(tmp["qualification"])
				mongo.db.staff.insert(tmp)
		os.remove(destination)
	return jsonify({"success":"true","message":"Successfully Uploaded"})


@app.route("/register",methods=["POST"])
def register():
	pass
	email = request.get_json()["email"]
	password = request.get_json()["password"]	
	code = request.get_json()["code"]
	role = request.get_json()["role"]
	code_found = mongo.db.codes.find_one({"email":email,"code":code})
	staff_unique_id = None
	mobile = ""
	if role=="staff":
		mobile = mongo.db.staff.find_one({"email":email},{"mobile_no":True,"_id":False})["mobile_no"]
	if role=="admin":
		mobile = mongo.db.admins.find_one({"email":email},{"mobile_no":True,"_id":False})["mobile_no"]
	if role=="hod":
		mobile = mongo.db.hods.find_one({"email":email},{"mobile_no":True,"_id":False})["mobile_no"]
	if role=="student":
		try:
			mobile = mongo.db.students.find_one({"email":email},{"mobile":True,"_id":False})["mobile"]
		except:
			res = mongo.db.students.find_one({"mobile":email},{"mobile":True,"_id":False,"email":True})

			email =  res["email"]
			mobile = res["mobile"]
	

	if code_found == None:
		return jsonify({"success":"false","message":"Sorry! Code does not match."})
	else:
		mongo.db.users.insert({"email":email, "password":hashlib.sha224(password).hexdigest(),"role":role,"mobile_no":mobile})
		if role=="hod":
			mongo.db.users.insert({"email":email, "password":hashlib.sha224(password).hexdigest(),"role":"staff","mobile_no":mobile})
		return jsonify({"success":"true","message":"Registration Successful ! Please Login!","mobile":mobile})

@app.route("/login",methods=["POST"])
def login():
	pass
	print request.get_json()
	email = request.get_json()["email"]
	password = request.get_json()["password"]
	try:
		acadyear = request.get_json()["acadyear"]
	except:
		acadyear = "2018-19"
	#print request.get_json()
 	role = ""
	try:
		role = request.get_json()["role"]	
	except:
		role = ""
	

	#if role == "":
	role_found = mongo.db.users.find_one({"email":re.compile('^' + re.escape(email) + '$', re.IGNORECASE)},{"role":True})	
	try:
		role = role_found["role"]	
	except:
		pass
	print role
	user_exist = mongo.db.users.find_one({"email":re.compile('^' + re.escape(email) + '$', re.IGNORECASE),"password":hashlib.sha224(password).hexdigest(),"role":role})
	if user_exist == None:
		user_exist = mongo.db.users.find_one({"mobile_no":email,"password":hashlib.sha224(password).hexdigest(),"role":role})
		
	if user_exist == None:
		return jsonify({"success":"false","message":"Sorry! User/Password/Role does not match!"})
	else:

		return jsonify({"success":"true","message":"Login Successful !","role":role,"mobile":str(user_exist["mobile_no"]),"email":email})


@app.route("/ccdetails",methods=["POST"])
def ccDetails():
	mobile = request.get_json()["mobile"]
	acadyear = request.get_json()["acadyear"]	
	classes = mongo.db.class_description.find({"class_coordinator":mobile,"acad_year":acadyear},{"_id":False})
	#classes = mongo.db.class_description.find({"class_coordinator":mobile},{"_id":False})
	cl = []
	for c in classes:
		cl.append(c)
	if len(cl)>0:
		return jsonify({"success":"true","message":"Login Successful !","classes":cl})		
	else:
		return jsonify({"success":"false","message":"Sorry! No class coordinator"})
		
@app.route("/getsubjects",methods=["POST"])
def getSubjects():
	mobile = request.get_json()["mobile"]	
	acadyear = request.get_json()["acadyear"]
	#print 
	iscc=  mongo.db.class_description.find_one({"class_coordinator":mobile,"acad_year":acadyear},{"_id":False,"class_coordinator":True})
	#iscc=  mongo.db.class_description.find_one({"class_coordinator":mobile},{"_id":False,"class_coordinator":True})
	classes = mongo.db.class_description.find({"class_coordinator":mobile,"acad_year":acadyear},{"_id":False})
	#classes = mongo.db.class_description.find({"class_coordinator":mobile},{"_id":False})
	#print classes
	classes = list(classes)
	cl = []
	for c in classes:
		#print c
		cl.append(c)
	#print cl
	result ={}
	#print "is class coordi",iscc,mobile
	if iscc!=None:
		iscc = "true"
	else:
		iscc ="false"
	#print mobile
	subjects = []
	#for cl1 in cl:
		#print cl1
	subjects_teaching = mongo.db.subjects.find({"faculty":mobile},{"_id":False})
	subjects_teaching = list(subjects_teaching)
	# for c in cl:
	# 	cc_subjects = mongo.db.subjects.find({"cuid":c["class_unique_id"]},{"_id":False})
	# 	cc_subjects = list(cc_subjects)
	# 	print cc_subjects
	# 	for sub in cc_subjects:
	# 		if sub not in subjects_teaching:
	# 			subjects_teaching.append(sub)



	for subject in subjects_teaching:
		#print subject
		#print subject["cuid"]
		yr = mongo.db.class_description.find_one({"class_unique_id":subject["cuid"]},{"acad_year":True,"_id":False})
		#print yr
		try:
			if yr["acad_year"] ==acadyear:
				subjects.append(subject)
		except:
			pass
		#subjects.append(subject)
	#print subjects
	branches =[]
	fetched_branches = mongo.db.branches.find()	
	for branch_name in fetched_branches:
		tmp = {}
		tmp["branch_short_form"] = branch_name["branch_short_form"]
		tmp["branch_long_form"] = branch_name["branch_long_form"]
		branches.append(tmp)		
	#print cl
	return jsonify({"success":"true","iscc":iscc,"subjects_teaching":subjects,"classes":cl,"branches":branches})
	
	

@app.route("/sendmail",methods=["POST"])
def sendMail():
	email = request.get_json()["email"]
	password = request.get_json()["password"]
	role = request.get_json()["role"]
	user_exist = mongo.db.users.find_one({"email":email,"role":role})
	if user_exist == None:
		user_exist = mongo.db.users.find_one({"mobile":email,"role":role})

	
	if user_exist == None:
		if role == "staff":
			usr = mongo.db.staff.find_one({"email":email})
		elif role == "student":
			usr = mongo.db.students.find_one({"email":email})
			if usr == None:
				usr = mongo.db.students.find_one({"mobile":email})				
		elif role == "admin":
			usr = mongo.db.admins.find_one({"email":email})
		elif role == "hod":
			usr = mongo.db.hods.find_one({"email":email})

		if usr == None:
			return jsonify({"success":"false","message":"Sorry! Email/Mobile no. not found in databasse. Please contact Class coordinator. "})
		else:
			codetosend = str(randint(100000,999999))
			mongo.db.codes.insert({"email":email,"code":codetosend})

			msg = Message("Welcome to JIT Attendance System ", sender = 'shindeashok.as.02@gmail.com', recipients = [usr["email"]])
			msg.body = 'Welcome!\n Your Code is '+codetosend+"\nThank you!"
			try:
				mail.send(msg)
			except:
				pass
			

			return jsonify({"success":"true","message":"Email  Successfully Sent! Please check you mail box!"})
	else:
		return jsonify({"success":"false","message":"User already Exist"})



@app.route('/addnewclass',methods=['POST'])
def addNewClass():
	acadyear = request.get_json()["acadyear"]
	id_exist = mongo.db.class_description.find_one({"class_unique_id":request.get_json()["class_unique_id"],"acad_year":acadyear})

	#id_exist = mongo.db.class_description.find_one({"class_unique_id":request.get_json()["class_unique_id"]})
	if id_exist== None:
		mongo.db.class_description.insert(request.get_json())
	else:
		return jsonify({"success":"false","reason":"Class Already Exist!"})
	return jsonify({"success":"true","message":"Successfully Added!"})

@app.route('/addnewsubject',methods=['POST'])
def addNewSubject():
	id_exist = mongo.db.subjects.find_one({"subject_uid":request.get_json()["cuid"]+request.get_json()["abbr"]+request.get_json()["unicode"]+request.get_json()["faculty"]})
	faculty_name = mongo.db.staff.find_one({"staff_unique_id":request.get_json()["faculty"]},{"_id":False,"staff_name":True})
	subject_to_insert = request.get_json()
	subject_to_insert["subject_uid"] = request.get_json()["cuid"]+request.get_json()["abbr"]+request.get_json()["unicode"]+request.get_json()["faculty"]
	subject_to_insert["faculty_name"] = faculty_name["staff_name"]
	
	if id_exist== None:
		mongo.db.subjects.insert(subject_to_insert)
	else:
		return jsonify({"success":"false","reason":"Subject Already Exist!"})
	return jsonify({"success":"true","message":"Successfully Added!"})


@app.route('/addnewstaff',methods=['POST'])
def addNewStaff():
	
	staff_exist_mobile = mongo.db.staff.find_one({"mobile_no":request.get_json()["mobile_no"]})
	staff_exist_email =   mongo.db.staff.find_one({"email":request.get_json()["email"]})
	if staff_exist_mobile== None and staff_exist_email == None:
		mongo.db.staff.insert(request.get_json())
	else:
		return jsonify({"success":"false","reason":"Staff Already Exist!"})
	return jsonify({"success":"true","message":"Successfully Added!"})	

@app.route('/updatestudent',methods=['POST'])
def updateStudent():
	edid = request.get_json()["id"]
	edrollno = request.get_json()["rollno"]
	edname = request.get_json()["name"]
	edemail = request.get_json()["email"]
	edmobile =  request.get_json()["mobile"]
	edparentmobile = request.get_json()["parentmobile"]   
	
	mongo.db.students.update({"_id":ObjectId(edid)} ,{"$set":{"rollno":edrollno,"name":edname,"email":edemail, "mobile":edmobile,"parent_mobile":edparentmobile}},upsert=False)	
	return jsonify({"success":"true","message":"Successfully Updated!"})	
	
	
@app.route('/addnewhod',methods=['POST'])
def addNewHOD():	
	staff_exist_mobile = mongo.db.hods.find_one({"mobile_no":request.get_json()["mobile_no"]})
	staff_exist_email =   mongo.db.hods.find_one({"email":request.get_json()["email"]})
	if staff_exist_mobile== None and staff_exist_email == None:
		mongo.db.hods.insert(request.get_json())
		staff_exist_mobile1 = mongo.db.staff.find_one({"mobile_no":request.get_json()["mobile_no"]})
		staff_exist_email1 =   mongo.db.staff.find_one({"email":request.get_json()["email"]})
		if staff_exist_mobile1== None and staff_exist_email1 == None:		
			mongo.db.staff.insert(request.get_json())
	else:
		return jsonify({"success":"false","reason":"Staff Already Exist!"})
	return jsonify({"success":"true","message":"Successfully Added!"})	


@app.route('/fetchstaff',methods=['POST'])
def fetchStaff():
	fetched_staff = mongo.db.staff.find({"branch": request.get_json()["branch"]})
	staff = []
	for st in fetched_staff:
		tmp = {}
		tmp["staff_name"] = st["staff_name"]
		tmp["staff_unique_id"] = st["staff_unique_id"]	
		staff.append(tmp)
	if len(staff)>0:
		return jsonify({"success":"true","staff":staff})
	else:
		return jsonify({"success":"false","reason":"No staff found. Please add staff!"})

		
@app.route('/fetchdeptstaff',methods=['POST'])
def fetchDeptStaff():
	acadyear = request.get_json()["acadyear"]
	branch = mongo.db.class_description.find_one({"class_unique_id":request.get_json()["cuid"],"acad_year":acadyear},{"branch":True,"_id":False})
	#branch = mongo.db.class_description.find_one({"class_unique_id":request.get_json()["cuid"]},{"branch":True,"_id":False})
	fetched_staff = mongo.db.staff.find({"branch": branch["branch"]})
	staff = []
	for st in fetched_staff:
		tmp = {}
		tmp["staff_name"] = st["staff_name"]
		tmp["staff_unique_id"] = st["staff_unique_id"]	
		staff.append(tmp)
	if len(staff)>0:
		return jsonify({"success":"true","staff":staff})
	else:
		return jsonify({"success":"false","reason":"No staff found. Please add staff!"})

from unidecode import unidecode
import string
def remove_non_ascii(s):
	#printable = set(string.printable)
	#filter(lambda x: x in printable, text)
	t =s 
	try:
		t = t.encode('ascii',errors='ignore')
	except:
		return s
	return t

		
@app.route('/fetchstudents',methods=['POST'])
def fetchStudents():
	if "batch" in request.get_json():
		fetched_students = mongo.db.students.find({"class": request.get_json()["class_uid"],"batch":request.get_json()["batch"]})
	else:
		fetched_students = mongo.db.students.find({"class": request.get_json()["class_uid"]})

	students_rec =[]
	for stud_rec in fetched_students:
		tmp ={}
		for key,val in stud_rec.iteritems():
			tmp[key] = str(val)
		students_rec.append(tmp)
	
	
	if len(students_rec)>0:
		return jsonify({"success":"true","students":students_rec})
	else:
		return jsonify({"success":"false","reason":"No Students found in this class"})

		

@app.route('/fetchsubjects',methods=['POST'])
def fetchSubjects():
	fetched_subjects = mongo.db.subjects.find({"cuid": request.get_json()["cuid"]},{"_id":False})
	subjects_rec =[]
	for stud_rec in fetched_subjects:
		tmp ={}
		for key,val in stud_rec.iteritems():
			tmp[key] = val
		subjects_rec.append(tmp)
	
	
	if len(subjects_rec)>0:
		return jsonify({"success":"true","subjects":subjects_rec})
	else:
		return jsonify({"success":"false","reason":"No Subjects found in this class"})

@app.route('/deleteStudent',methods=['POST'])
def deleteStudent():
	id_to_delete = request.get_json()["id"]
	try:
		mongo.db.students.remove({"_id":ObjectId(id_to_delete)})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})

@app.route('/deletesession',methods=['POST'])
def deleteSession():
	id_to_delete = request.get_json()["id"]
	try:
		mongo.db.attendance.remove({"_id":ObjectId(id_to_delete)})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})

		
		
@app.route('/deleteallstudents',methods=['POST'])
def deleteAllStudents():
	selectedclass = request.get_json()["selectedclass"]
	print selectedclass 
	try:
		mongo.db.students.remove({"class":selectedclass})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})
		
		
@app.route('/deletestaff',methods=['POST'])
def deleteStaff():
	id_to_delete = request.get_json()["id"]
	try:
		mongo.db.hods.remove({"staff_unique_id":id_to_delete})	
		mongo.db.staff.remove({"staff_unique_id":id_to_delete})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})

		
@app.route('/deleteclass',methods=['POST'])
def deleteClass():
	id_to_delete = request.get_json()["id"]
	try:
		mongo.db.class_description.remove({"class_unique_id":id_to_delete})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})
		
@app.route('/deletesubject',methods=['POST'])
def deleteSubject():
	id_to_delete = request.get_json()["id"]
	try:
		mongo.db.subjects.remove({"subject_uid":id_to_delete})	
		return jsonify({"success":"true","message":"Deleted Successfully!"})
	except:
		return jsonify({"success":"false","message":"Something is wrong!"})

		
@app.route('/getallclasses',methods=['POST'])
def getAllClasses():
	mobile = request.get_json()["mobile"]
	print request.get_json()
	acadyear = request.get_json()["acadyear"]
	branch = mongo.db.hods.find_one({"mobile_no":mobile},{"branch":True,"_id":False})
	
	recs =mongo.db.class_description.find({"currently_active":"1","branch":branch["branch"],"acad_year":acadyear},{"_id":False})
	#recs =mongo.db.class_description.find({"currently_active":"1","branch":branch["branch"]},{"_id":False})
	classes =[]
	for r in recs:
		tmp ={}
		for k,v in r.iteritems():
			tmp[k] = v
			if k=='class_coordinator':
				staff_name = mongo.db.staff.find_one({"staff_unique_id":v},{'_id':False,"staff_name":True})
				if staff_name!= None:
					tmp[k] = staff_name["staff_name"]
		
					classes.append(tmp)
	if len(classes)==0:
		return jsonify({"success":"false","reason":"No Class Added!"})
	return jsonify({"success":"true","allclasses":classes})

@app.route('/getbranches',methods=["GET"])
def getbranches():
	
	fetched_branches = mongo.db.branches.find({},{"_id":False})
	fetched_hods = mongo.db.hods.find({},{"_id":False})
	branches = []
	hods = []
	for br in fetched_branches:
		branches.append(br)
	for hod in fetched_hods:
	   hods.append(hod)
	return jsonify({"branches":branches,"success":True,"hods":hods})




@app.route('/getclasses',methods=["POST"])
def getclasses():
	mobile = request.get_json()["mobile"]
	branch = mongo.db.hods.find_one({"mobile_no":mobile},{"branch":True,"_id":False})
	home_branch = branch["branch"]
	print home_branch
	fetched_hods = mongo.db.hods.find({},{"_id":False})
	fetched_classes = mongo.db.class_names.find()
	recs = []
	hods=[]
	for hod in fetched_hods:
	   hods.append(hod)

	for class_name in fetched_classes:
		tmp = {}
		tmp["class_short_name"] = class_name["class_short_name"]
		tmp["class_long_name"] = class_name["class_long_name"]
		tmp["priority"] = class_name["priority"]
		recs.append(tmp)

	branches =[]
	fetched_branches = mongo.db.branches.find({})	

	for branch_name in fetched_branches:
		tmp = {}
		tmp["branch_short_form"] = branch_name["branch_short_form"]
		tmp["branch_long_form"] = branch_name["branch_long_form"]
		branches.append(tmp)

	divs =[]
	fetched_divs = mongo.db.divisions.find()	
	for div in fetched_divs:
		tmp = {}
		tmp["division_name"] = div["division_name"]	
		divs.append(tmp)
	
	staff =[]
	fetched_staff = mongo.db.staff.find({"branch":branch["branch"]})	

	for st in fetched_staff:
		
		tmp = {}
		tmp["staff_name"] = st["staff_name"]
		tmp["qualification"]=st["qualification"]
		tmp["email"]= st["email"]
		tmp["mobile_no"]=st["mobile_no"]
		tmp["staff_unique_id"] = st["staff_unique_id"]	
		staff.append(tmp)
	
	classrooms =[]
	fetched_classrooms = mongo.db.classrooms.find()	
	for classroom in fetched_classrooms:
		tmp = {}
		tmp["class_room_no"] = classroom["class_room_no"]
		classrooms.append(tmp)

	acad_year =[]
	fetched_acad_year = mongo.db.acad_year.find()	
	for ay in fetched_acad_year:
		tmp = {}
		tmp["name"] = ay["name"]
		acad_year.append(tmp)

	semesters =[]
	fetched_sems = mongo.db.semesters.find()	
	for sem in fetched_sems:
		tmp = {}
		tmp["number"] = sem["number"]
		semesters.append(tmp)

	print home_branch
	return jsonify({"classnames":recs,
		"branches":branches,
		"divisions":divs,
		"staff":staff,
		"classrooms":classrooms,
		"acad_year":acad_year,
		"semesters":semesters,
		"hods":hods,
		"home_branch":home_branch
		})


@app.route('/createbatch',methods=['POST'])
def createBatch():
	cuid = request.get_json()["class_uid"]
	batchname = request.get_json()["batchname"]
	firstrollno = request.get_json()["firstrollno"]
	lastrollno = request.get_json()["lastrollno"]
	print firstrollno,lastrollno
	for rollno in range(firstrollno,lastrollno+1):
		print rollno
		print cuid
		rid = mongo.db.students.find_one({"rollno":str(rollno),"class":cuid})
		if rid == None:
			rid = mongo.db.students.find_one({"rollno":int(rollno),"class":cuid})

		
		if rid!=None:
			mongo.db.students.update({"_id":rid["_id"]} ,{"$set":{"batch":batchname}},upsert=False)
		else:
			print rollno
	return jsonify({"success":"true","message":"Successfully Added"})

@app.route('/getbatches',methods=['POST'])
def getBatches():
	cuid = request.get_json()["class_uid"]
	batches =mongo.db.students.find({"class": cuid}).distinct("batch")
	
	if len(batches)>0:
		return jsonify({"success":"true","batches": batches})
	else:
		return jsonify({"success":"false","reason": "No batch found!"})



@app.route('/deactiveclass',methods=["POST"])
def deactivateClass():
	class_uid = request.get_json()["class_unique_id"]
	mongo.db.class_description.update({"class_unique_id":class_uid},{"$set":{"currently_active":"0"}}, False,True)
	return jsonify({"success":"true","message":"Successfully Deleted"})


@app.route('/sendmessage',methods=["POST"])
def sendmessage():
	mobilenos = request.get_json()["mobilenos"]
	message = request.get_json()["message"]
	sender = request.get_json()["sender"]
	smsurl = "http://www.smsjust.com/blank/sms/user/urlsms.php?username=Gokhalenew&pass=123456&senderid=GESCOE&dest_mobileno="
	for num in mobilenos:
		smsurl+=str(num)+","
	smsurl=smsurl[:-1]
	smsurl+="&message="
	smsurl+=message
	smsurl+="&response=Y"
	sresponse = requests.get(smsurl,timeout=5)
	mongo.db.smscounter.insert({"mobilenos":mobilenos,"message":message,"sender":sender})
	return jsonify({"success":"true","message":"Successfully Sent!"})

@app.route("/forgotpwd",methods=["POST"])
def forgotPwd():
	emailmobile = request.get_json()["emailmobile"]
	role = request.get_json()["role"]
	user_exist = mongo.db.users.find_one({"email":emailmobile,"role":role})
	if user_exist == None:
		user_exist = mongo.db.users.find_one({"mobile_no":emailmobile,"role":role})
		
	
	if user_exist != None:
		if role == "staff":
			usr = mongo.db.staff.find_one({"email":user_exist["email"]})
		elif role == "student":
			usr = mongo.db.students.find_one({"email":user_exist["email"]})
		elif role == "admin":
			usr = mongo.db.admins.find_one({"email":user_exist["email"]})
		elif role == "hod":
			usr = mongo.db.hods.find_one({"email":user_exist["email"]})

		if usr == None:
			return jsonify({"success":"false","message":"Sorry ! User does not exist!"})
		else:
			codetosend = str(randint(100000,999999))
			mongo.db.codes.insert({"email":user_exist["email"],"code":codetosend})
			msg = Message("Forgot Password ", sender = 'swap.mythbuster@gmail.com', recipients = [user_exist["email"]])
			msg.body = ' Your Code is '+codetosend+"\nThank you!"
			mail.send(msg)
			message=" Your code is "+codetosend
			#print usr["mobile_no"]
			smsurl = "http://www.smsjust.com/blank/sms/user/urlsms.php?username=Gokhalenew&pass=123456&senderid=GESCOE&dest_mobileno="
			if role =="student":
				smsurl+=usr["mobile"]
			else:
				smsurl+=usr["mobile_no"]
				
			smsurl+="&message="
			smsurl+=message
			smsurl+="&response=Y"
			sresponse = requests.get(smsurl,timeout=30)

			return jsonify({"success":"true","message":"Code Sent! Please check you message/mail box!"})
	else:
		return jsonify({"success":"false","message":"User does not exist"})

@app.route("/passwordreset",methods=["POST"])
def passwordReset():
	emailmobile = request.get_json()["emailmobile"]
	code = request.get_json()["code"]
	role = request.get_json()["role"]
	pwd = request.get_json()["pwd"]
	
	user_exist = mongo.db.users.find_one({"email":emailmobile,"role":role})
	if user_exist == None:
		user_exist = mongo.db.users.find_one({"mobile_no":emailmobile,"role":role})
	
	if user_exist ==None:
		return jsonify({"success":"false","message":"User does not exist"})
	else:
		code_exist = mongo.db.codes.find_one({"email":user_exist["email"],"code":code})
		if code_exist == None:
			return jsonify({"success":"false","message":"Code does not match!"})
		else:
			mongo.db.users.update({"email":user_exist["email"],"role":role},{'$set':{'password':hashlib.sha224(pwd).hexdigest()}})
			return jsonify({"success":"true","message":"Password Changes Successfully! Please login with new password."})	


@app.route("/getclassattendance",methods=["POST"])
def getclassattendance():
	classid = request.get_json()["classid"]
	recs = mongo.db.attendance.find({"class_uid":classid},{"presenty":False,"_id":False})
	recs = list(recs)
	tempAttendance = []
	for att in recs:
			try:
				datetocomp = dt.strptime(att["sessiondate"], "%d-%m-%Y")
			except:
				datetocomp = dt.strptime(att["sessiondate"], "%d/%m/%Y")
			att["datetocomp"] = datetocomp
			epoch_time = (datetocomp - datetime(1970, 1, 1)).total_seconds()
			att["epoch"] = epoch_time+int(att["sessiontime"].split(":")[0])+int(att["sessiontime"].split(":")[1])
			
			#if datetocomp >= startdate and datetocomp <= enddate:				
			tempAttendance.append(att)


	recs = sorted(tempAttendance, key=itemgetter('epoch'),reverse =True)
	#print recs
	return jsonify({"success":"true","recs":recs})

@app.route("/addindstudent",methods=["POST"])
def addIndStudent():
	print request.get_json()

	mongo.db.students.insert(request.get_json())
	return jsonify({"success":"true","message":"Successfully Added"})


@app.route("/uploadimg", methods=["POST"])
def uploadimg():
	filename =""
	target="/opt/lampp/htdocs/uploads"
	'''
	for upload in request.files.getlist("file"):
		filename = upload.filename
		destination = "/".join([target, filename])		
		upload.save(destination)
	'''
	print requests.files
	return jsonify({"success":"true"})
	
	
if __name__=="__main__":
	app.run(debug=True,host='0.0.0.0',port=4444)