import os 
os.system("sudo python net.py") 
'''
os.system("cd ns-allinone-2.35") 
os.system("./configure") 
os.system("./install.sh") 
os.system("make") 
os.system("make install") 
os.system("ldconfig") 
'''



