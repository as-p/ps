/*********************************
Title  :Write a program using TCP socket for wired network for following:
  Say Hello to Each other (client side)
Class  :TEB-3   
Roll No:61
********************************/
#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<netinet/in.h> 
#include <unistd.h>
#include<string.h> 
#include<strings.h>
#include <arpa/inet.h>

//#define buffsize  150
void main()
{
int b,sockfd,sin_size,con,n,len;
//char buff[256];
char msg[100];
if((sockfd=socket(AF_INET,SOCK_STREAM,0))>0)
printf("socket created sucessfully\n");
//printf("%d\n", sockfd);
struct sockaddr_in servaddr;

servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
servaddr.sin_port=5003;

sin_size = sizeof(struct sockaddr_in);
if((con=connect(sockfd,(struct sockaddr *) &servaddr, sin_size))==0); //initiate a connection on a socket
printf("connect sucessful\n");
printf("Enter the message:\n");
scanf("%s",msg);

write(sockfd,&msg,sizeof(msg));
//read(sockfd,&msg,sizeof(msg)); 
 
close(sockfd);
}
/*
Output:-
gescoe@gescoe-OptiPlex-3020:~/Desktop/a$ gcc cchat.c
gescoe@gescoe-OptiPlex-3020:~/Desktop/a$ ./a.out
socket created sucessfully
connect sucessful
Enter the message:
hii
gescoe@gescoe-OptiPlex-3020:~/Desktop/a$ 
*/

